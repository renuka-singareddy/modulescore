package com.mou.DAO;

import java.sql.SQLException;

import com.mou.bean.AssessmentBean;
import com.mou.service.*;

public interface IAssessmentDAO {

	void addassesment(AssessmentBean assbean) throws SQLException;

}
