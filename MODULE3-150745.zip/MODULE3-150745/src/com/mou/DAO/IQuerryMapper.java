package com.mou.DAO;

public class IQuerryMapper {
	static final String INSERTMARKS="INSERT into AssessmentScore VALUES(?,?,?,?,?,?,?)";

}
