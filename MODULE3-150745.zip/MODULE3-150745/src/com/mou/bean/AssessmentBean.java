package com.mou.bean;

public class AssessmentBean {
	long traineeid;
	String modulename;
	float mpt;
	float mtt;
	float assignment;
	float totalmarks;
	int grade;
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public long getTraineeid() {
		return traineeid;
	}
	public void setTraineeid(long traineeid) {
		this.traineeid = traineeid;
	}
	public String getModulename() {
		return modulename;
	}
	public void setModulename(String modulename) {
		this.modulename = modulename;
	}
	public float getMpt() {
		return mpt;
	}
	public void setMpt(float mpt) {
		this.mpt = mpt;
	}
	public float getMtt() {
		return mtt;
	}
	public void setMtt(float mtt) {
		this.mtt = mtt;
	}
	public float getAssignment() {
		return assignment;
	}
	public void setAssignment(float assignment) {
		this.assignment = assignment;
	}
	public float getTotalmarks() {
		return totalmarks;
	}
	public void setTotalmarks(float totalmarks) {
		this.totalmarks = totalmarks;
	}
	

}
