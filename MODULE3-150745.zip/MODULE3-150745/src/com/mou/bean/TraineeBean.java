package com.mou.bean;

public class TraineeBean {
	long Traineeid;
	String Traineename;
	public long getTraineeid() {
		return Traineeid;
	}
	public void setTraineeid(long traineeid) {
		Traineeid = traineeid;
	}
	public String getTraineename() {
		return Traineename;
	}
	public void setTraineename(String traineename) {
		Traineename = traineename;
	}

}
