package com.mou.dto;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mou.exception.MyException;
import com.mou.bean.AssessmentBean;
import com.mou.bean.TraineeBean;
import com.mou.service.AssignServiceImpl;
import com.mou.service.IAssignService;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String option=request.getParameter("action");
		if(option.equals("addassesment")){
			getServletContext().getRequestDispatcher("/addassessment.jsp").forward(request,response);			
		}
		else if(option.equals("submit")){
			try {
			TraineeBean train=new TraineeBean();
			Long traineeid=Long.parseLong(request.getParameter("trainid"));
			String modulename=request.getParameter("module");
			float mpt=Float.parseFloat(request.getParameter("mpt"));
			float mtt=Float.parseFloat(request.getParameter("mtt"));
			float assign=Float.parseFloat(request.getParameter("assignment"));
			 int grade=0;
			 float totalscore=0;
			if(assign<=15f && assign>=0 && mtt<=15f && mtt>=0 && mpt>=0 && mpt<=70f && totalscore<=100f){
			response.setContentType("text/html");
		    out=response.getWriter();
		    train.setTraineeid(traineeid);
		    IAssignService iasign=new AssignServiceImpl();
		    totalscore=mpt+mtt+assign;
		    if(totalscore<49){
		        grade=0;
		    }
		    else if(totalscore>=50 && totalscore<=59){
		    	grade=1;
		    }
		    else if(totalscore>=60 && totalscore<=69){
		    	grade=2;
		    }
		    else if(totalscore>=70 && totalscore<=79){
		    	grade=3;
		    }
		    else if(totalscore>=80 && totalscore<=89){
		    	grade=4;
		    }
		    else{
		    	grade=5;
		    }
			
		    AssessmentBean assbean=new  AssessmentBean();
		    assbean.setTraineeid(train.getTraineeid());
		    assbean.setModulename(modulename);
		    assbean.setMpt(mpt);
		    assbean.setMtt(mtt);
		    assbean.setAssignment(assign);
		    assbean.setTotalmarks(totalscore);
		    assbean.setGrade(grade);
		    
				iasign.addassesment(assbean);
				request.setAttribute("assign", assbean);
				request.setAttribute("trainee", train);
				getServletContext().getRequestDispatcher("/moduleresult.jsp").forward(request,response);
			} else{
				//out.println("invalid consumer number");
				request.setAttribute("error",new MyException("Invalid marks entered"));
				getServletContext().getRequestDispatcher("/Errorinfo.jsp").forward(request,response);
				}
			}
				catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
}
		}
	}
}
