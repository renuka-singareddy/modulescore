package com.mou.service;


import java.sql.SQLException;

import com.mou.DAO.AssignDAOImpl;
import com.mou.DAO.IAssessmentDAO;
import com.mou.bean.AssessmentBean;

public class AssignServiceImpl implements IAssignService {

	@Override
	public void addassesment(AssessmentBean assbean) throws SQLException{
		// TODO Auto-generated method stub
		IAssessmentDAO iassigndao=new AssignDAOImpl();
		iassigndao.addassesment(assbean);
		
	}

}
