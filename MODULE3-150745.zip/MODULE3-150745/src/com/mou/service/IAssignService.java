package com.mou.service;

import java.sql.SQLException;

import com.mou.bean.AssessmentBean;

public interface IAssignService {

	void addassesment(AssessmentBean assbean) throws SQLException;

}
