CREATE TABLE trainees(trainee_id NUMBER PRIMARY KEY,trainee_name VARCHAR2(30));
INSERT INTO trainees VALUES(898983,'TINA');
INSERT INTO trainees VALUES(898984,'VINA');
INSERT INTO trainees VALUES(898985,'GITA');
INSERT INTO trainees VALUES(898986,'RITA');
INSERT INTO trainees VALUES(898987,'SITA');
INSERT INTO trainees VALUES(898988,'MALA');
CREATE TABLE AssessmentScore(trainee_id number REFERENCES trainees(trainee_id),
module_name varchar2(30),
mpt number,
mtt number,
ass_marks number,
total number,
grade number);